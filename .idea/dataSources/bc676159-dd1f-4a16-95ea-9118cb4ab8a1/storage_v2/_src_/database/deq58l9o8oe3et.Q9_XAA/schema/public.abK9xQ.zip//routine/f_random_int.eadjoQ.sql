create function f_random_int(length integer) returns text
    language sql
as
$$
WITH chars AS (
    SELECT unnest(string_to_array('0 1 2 3 4 5 6 7 8 9', ' ')) AS _char
),
     charlist AS
         (
             SELECT _char FROM chars ORDER BY random() LIMIT $1
         )
SELECT string_agg(_char, '')
FROM charlist
    ;
$$;

alter function f_random_int(integer) owner to vwemxptfpegfam;

